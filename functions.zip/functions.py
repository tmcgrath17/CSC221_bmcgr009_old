'''
functions module
Author: Brady McGrath
'''


import math

def make_car(manufacturer,model,**car):
  '''
  Creates a car with a specified manufacturer and model as well as
  any other extra info passed in
  '''
  car['manufacturer'] = manufacturer
  car['model'] = model
  return car

def combine(num1,num2=math.pi,verbose=False):
  '''
  Combines two numbers and returns the sum and a sorted list.
  The second number defaults to pi.
  '''
  if verbose:
    print(f"The two values are {num1} and {num2}")
    print(f"The values add to {num1+num2} and are sorted to {sorted([num1,num2])}")
  return num1+num2, sorted([num1,num2])

if __name__ == '__main__':
    car = make_car('toyota','prius',color='green',mileage=12000)
    print(car)
    car = make_car('toyota','prius')
    print(car)
    combine(8,3)
    combine(1,2)
    combine(4)
    combine(4,3,True)
    combine(10,15,True)
    combine(3,verbose=True)