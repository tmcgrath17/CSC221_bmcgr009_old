import functions

car = functions.make_car('honda','civic',color='white',mileage=1000)
print(car)

functions.combine(10,15,True)